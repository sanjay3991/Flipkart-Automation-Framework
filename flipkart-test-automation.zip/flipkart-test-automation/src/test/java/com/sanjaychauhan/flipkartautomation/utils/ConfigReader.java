package com.sanjaychauhan.flipkartautomation.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {

    private Properties properties;

    // Constructor to load the properties file
    public ConfigReader() {
        properties = new Properties();
        try (FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/src/test/resources/config.properties")) {
            properties.load(fis);  // Load the properties file
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Get base URL
    public String getBaseURL() {
        return properties.getProperty("baseURL");
    }

    // Get browser type
    public String getBrowser() {
        return properties.getProperty("browser");
    }

    // Get implicit wait time
    public int getImplicitWait() {
        return Integer.parseInt(properties.getProperty("implicitWait"));
    }

    // Get explicit wait time
    public int getExplicitWait() {
        return Integer.parseInt(properties.getProperty("explicitWait"));
    }

    // Get screenshot path
    public String getScreenshotPath() {
        return properties.getProperty("screenshotPath");
    }
}
